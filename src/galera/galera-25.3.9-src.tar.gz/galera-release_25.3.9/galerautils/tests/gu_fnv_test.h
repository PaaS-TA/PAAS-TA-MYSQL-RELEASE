// Copyright (C) 2012 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_fnv_test__
#define __gu_fnv_test__

#include <check.h>

extern Suite *gu_fnv_suite(void);

#endif /* __gu_fnv_test__ */
