// Copyright (C) 2013 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_alloc_test__
#define __gu_alloc_test__

#include <check.h>

extern Suite *gu_alloc_suite(void);

#endif /* __gu_alloc_test__ */
