// Copyright (C) 2012 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_spooky_test__
#define __gu_spooky_test__

#include <check.h>

extern Suite *gu_spooky_suite(void);

#endif /* __gu_spooky_test__ */
