// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_mem_test__
#define __gu_mem_test__

extern Suite *gu_mem_suite(void);

#endif /* __gu_mem_test__ */
