// Copyright (C) 2012 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_hash_test__
#define __gu_hash_test__

#include <check.h>

extern Suite *gu_hash_suite(void);

#endif /* __gu_hash_test__ */
