// Copyright (C) 2013 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_config_test__
#define __gu_config_test__

#include <check.h>

extern Suite *gu_config_suite(void);

#endif /* __gu_config_test__ */
