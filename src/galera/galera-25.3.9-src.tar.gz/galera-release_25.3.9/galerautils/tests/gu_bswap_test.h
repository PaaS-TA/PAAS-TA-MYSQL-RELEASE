// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_bswap_test__
#define __gu_bswap_test__

Suite *gu_bswap_suite(void);

#endif /* __gu_bswap_test__ */
