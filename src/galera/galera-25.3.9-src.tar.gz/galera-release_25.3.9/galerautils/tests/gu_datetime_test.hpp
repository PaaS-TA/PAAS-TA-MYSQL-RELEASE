/*
 * Copyright (C) 2009 Codership Oy <info@codership.com>
 *
 * $Id$
 */
#ifndef __gu_datetime_test_hpp__
#define __gu_datetime_test_hpp__

#include <check.h>

Suite* gu_datetime_suite();

#endif // __gu_datetime_test_hpp__
