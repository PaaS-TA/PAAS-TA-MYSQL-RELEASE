/*
 * Copyright (C) 2014 Codership Oy <info@codership.com>
 */

#ifndef __gu_histogram_test__
#define __gu_histogram_test__

#include <check.h>

extern Suite *gu_histogram_suite(void);

#endif // __gu_histogram_test__
