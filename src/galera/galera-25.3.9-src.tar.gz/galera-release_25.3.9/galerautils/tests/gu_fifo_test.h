// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_fifo_test__
#define __gu_fifo_test__

Suite *gu_fifo_suite(void);

#endif /* __gu_fifo_test__ */
