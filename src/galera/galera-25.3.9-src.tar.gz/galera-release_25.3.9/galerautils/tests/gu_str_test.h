// Copyright (C) 2007 Codership Oy <info@codership.com>



#ifndef __gu_str_test__
#define __gu_str_test__

extern Suite *gu_str_suite(void);

#endif /* __gu_str_test__ */
