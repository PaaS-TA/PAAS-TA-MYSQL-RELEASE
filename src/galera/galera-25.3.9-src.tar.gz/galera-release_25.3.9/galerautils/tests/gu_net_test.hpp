// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_net_test__
#define __gu_net_test__

#include <check.h>

extern Suite *gu_net_suite(void);

#endif /* __gu_net_test__ */
