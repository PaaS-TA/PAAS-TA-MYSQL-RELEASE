/*
 * Copyright (C) 2013 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gu_crc32c_test_h__
#define __gu_crc32c_test_h__

#include <check.h>

Suite* gu_crc32c_suite(void);

#endif /* __gu_crc32c_test_h__ */
