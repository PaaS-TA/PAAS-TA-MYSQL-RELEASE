// Copyright (C) 2014 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_atomic_test__
#define __gu_atomic_test__

#include <check.h>

Suite *gu_atomic_suite(void);

#endif /* __gu_atomic_test__ */
