/*
 * Copyright (C) 2014 Codership Oy <info@codership.com>
 */

#ifndef __gu_stats_test__
#define __gu_stats_test__

#include <check.h>

extern Suite *gu_stats_suite(void);

#endif // __gu_stats_test__
