/* Copyright (C) 2013 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gu_rset_test__
#define __gu_rset_test__

#include <check.h>

Suite *gu_rset_suite(void);

#endif /* __gu_rset_test__ */
