// Copyright (C) 2013 Codership Oy <info@codership.com>

// $Id$

#ifndef __gu_mem_pool_test__
#define __gu_mem_pool_test__

#include <check.h>

extern Suite *gu_mem_pool_suite(void);

#endif /* __gu_mem_pool_test__ */
